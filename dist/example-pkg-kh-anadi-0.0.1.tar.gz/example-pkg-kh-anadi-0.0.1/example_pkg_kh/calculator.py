class Calculator:

    def sum(self, a = 0, b = 0):
        return (a + b)

